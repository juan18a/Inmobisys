import React, { useState } from 'react';
import { Link, usePage } from '@inertiajs/react';
import { dashboard, login } from '@/routes';
import SearchNav from '../custom/SearchNav';

export default function Navbar() {
    const [menuOpen, setMenuOpen] = useState(false);
    const { auth } = usePage().props as any;

    // Detectar en qué página estamos para apuntar el buscador
    // a la ruta correcta: landing (/) o galería pública (/properties)
    const isLanding = typeof window !== 'undefined'
        ? window.location.pathname === '/'
        : true;

    const searchRoute = isLanding ? 'home' : 'properties.index';

    return (
        <header className="fixed top-0 left-0 right-0 z-50 px-4 md:px-0">
            <nav
                className="bg-white/70 dark:bg-slate-900/70 backdrop-blur-xl rounded-full mt-6 mx-auto max-w-5xl border border-white/20 dark:border-slate-700/30 shadow-2xl shadow-blue-900/10 flex flex-col px-6 py-3 w-full transition-all duration-300"
                style={{ borderRadius: menuOpen ? '1.5rem' : '9999px' }}
            >
                {/* Top row */}
                <div className="flex justify-between items-center w-full">

                    {/* Logo */}
                    <a
                        className="text-xl md:text-2xl font-bold text-blue-900 dark:text-blue-50 font-headline tracking-tighter shrink-0"
                        href="#"
                    >
                        Ethereal Estate
                    </a>

                    {/* Desktop */}
                    <div className="hidden md:flex items-center gap-6">

                        {/* Buscador — apunta a home (/) en landing o a /properties en galería */}
                        {/**           <SearchNav
                            routeName={searchRoute}
                            placeholder="Search architecture..."
                        />
*/}
                        {/* Nav links */}

                        {/** 
                        <div className="flex items-center gap-6 font-manrope font-semibold tracking-tight">
                            <a className="text-blue-900 dark:text-white border-b-2 border-blue-900 pb-1" href="#">Propiedades</a>
                            <a className="text-blue-800/60 dark:text-slate-400 hover:text-blue-900 transition-all duration-300" href="#">Sobre Nosotros</a>
                            <a className="text-blue-800/60 dark:text-slate-400 hover:text-blue-900 transition-all duration-300" href="#">Contacto</a>
                        </div>

                        */}

                        {/* Actions */}
                        <div className="flex items-center gap-3">
                            {auth.user ? (
                                <Link
                                    href={dashboard()}
                                    className="bg-secondary text-on-primary px-5 py-2 rounded-full font-headline font-bold text-sm hover:scale-95 active:scale-90 transition-transform"
                                >
                                    Dashboard
                                </Link>
                            ) : (
                                <Link
                                    href={login()}
                                    className="material-symbols-outlined text-secondary scale-95 active:scale-90 transition-transform p-2 rounded-full hover:bg-blue-50/50"
                                >
                                    account_circle
                                </Link>
                            )}
                        </div>
                    </div>

                    {/* Mobile: hamburger */}
                    <div className="flex md:hidden items-center gap-2">
                        <button className="material-symbols-outlined text-secondary p-2 rounded-full hover:bg-blue-50/50 active:scale-90 transition-transform">
                            account_circle
                        </button>
                        <button
                            onClick={() => setMenuOpen(!menuOpen)}
                            className="p-2 rounded-full hover:bg-blue-50/50 active:scale-90 transition-transform text-blue-900 dark:text-white"
                            aria-label="Toggle menu"
                        >
                            <span className="material-symbols-outlined text-secondary">
                                {menuOpen ? 'close' : 'menu'}
                            </span>
                        </button>
                    </div>
                </div>

                {/* Mobile menu */}
                {menuOpen && (
                    <div className="flex md:hidden flex-col gap-4 pt-4 pb-2 border-t border-blue-900/10 dark:border-slate-700/30 mt-3">

                        {/* Mobile search */}
                        {/*            <SearchNav
                            routeName={searchRoute}
                            placeholder="Buscar propiedades..."
                        /> */}

                        {/* Mobile nav links */}
                        {/*               <div className="flex flex-col gap-1 font-manrope font-semibold tracking-tight">
                            <a className="text-blue-900 dark:text-white px-2 py-2 rounded-xl hover:bg-blue-50/50 transition-colors" href="#">Propiedades</a>
                            <a className="text-blue-800/60 dark:text-slate-400 px-2 py-2 rounded-xl hover:bg-blue-50/50 hover:text-blue-900 transition-colors" href="#">Sobre Nosotros</a>
                            <a className="text-blue-800/60 dark:text-slate-400 px-2 py-2 rounded-xl hover:bg-blue-50/50 hover:text-blue-900 transition-colors" href="#">Contacto</a>
                        </div> */}

                        {/* Mobile CTA */}
                        {auth.user ? (
                            <Link
                                href={dashboard()}
                                className="w-full text-center bg-secondary text-on-primary px-6 py-2.5 rounded-full font-headline font-bold text-sm hover:scale-95 active:scale-90 transition-transform"
                            >
                                Dashboard
                            </Link>
                        ) : (
                            <Link
                                href={login()}
                                className="w-full text-center bg-secondary text-on-primary px-6 py-2.5 rounded-full font-headline font-bold text-sm hover:scale-95 active:scale-90 transition-transform"
                            >
                                Iniciar sesión
                            </Link>
                        )}
                    </div>
                )}
            </nav>
        </header>
    );
}