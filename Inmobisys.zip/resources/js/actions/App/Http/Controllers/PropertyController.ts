import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
export const landing = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: landing.url(options),
    method: 'get',
})

landing.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
landing.url = (options?: RouteQueryOptions) => {
    return landing.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
landing.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: landing.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
landing.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: landing.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
    const landingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: landing.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
        landingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: landing.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::landing
 * @see app/Http/Controllers/PropertyController.php:104
 * @route '/'
 */
        landingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: landing.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    landing.form = landingForm
/**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/properties',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::index
 * @see app/Http/Controllers/PropertyController.php:22
 * @route '/properties'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/properties/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::create
 * @see app/Http/Controllers/PropertyController.php:147
 * @route '/properties/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\PropertyController::store
 * @see app/Http/Controllers/PropertyController.php:154
 * @route '/properties'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/properties',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PropertyController::store
 * @see app/Http/Controllers/PropertyController.php:154
 * @route '/properties'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::store
 * @see app/Http/Controllers/PropertyController.php:154
 * @route '/properties'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PropertyController::store
 * @see app/Http/Controllers/PropertyController.php:154
 * @route '/properties'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PropertyController::store
 * @see app/Http/Controllers/PropertyController.php:154
 * @route '/properties'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
export const edit = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/properties/{property}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
edit.url = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { property: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { property: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                }

    return edit.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
edit.get = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
edit.head = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
    const editForm = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
        editForm.get = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::edit
 * @see app/Http/Controllers/PropertyController.php:193
 * @route '/properties/{property}/edit'
 */
        editForm.head = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
export const update = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/properties/{property}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
update.url = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { property: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { property: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                }

    return update.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
update.put = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
update.patch = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
    const updateForm = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
        updateForm.put = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\PropertyController::update
 * @see app/Http/Controllers/PropertyController.php:205
 * @route '/properties/{property}'
 */
        updateForm.patch = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:257
 * @route '/properties/{property}'
 */
export const destroy = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/properties/{property}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:257
 * @route '/properties/{property}'
 */
destroy.url = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { property: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { property: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                }

    return destroy.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:257
 * @route '/properties/{property}'
 */
destroy.delete = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:257
 * @route '/properties/{property}'
 */
    const destroyForm = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:257
 * @route '/properties/{property}'
 */
        destroyForm.delete = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\PropertyController::destroyImage
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
export const destroyImage = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyImage.url(args, options),
    method: 'delete',
})

destroyImage.definition = {
    methods: ["delete"],
    url: '/properties/{property}/images/{image}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PropertyController::destroyImage
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
destroyImage.url = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return destroyImage.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::destroyImage
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
destroyImage.delete = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyImage.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PropertyController::destroyImage
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
    const destroyImageForm = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyImage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PropertyController::destroyImage
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
        destroyImageForm.delete = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyImage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyImage.form = destroyImageForm
/**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
export const show = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/properties/{property}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
show.url = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { property: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { property: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                }

    return show.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
show.get = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
show.head = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
    const showForm = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
        showForm.get = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::show
 * @see app/Http/Controllers/PropertyController.php:182
 * @route '/properties/{property}'
 */
        showForm.head = (args: { property: string | { slug: string } } | [property: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
export const apiIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiIndex.url(options),
    method: 'get',
})

apiIndex.definition = {
    methods: ["get","head"],
    url: '/api/properties',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
apiIndex.url = (options?: RouteQueryOptions) => {
    return apiIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
apiIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: apiIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
apiIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: apiIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
    const apiIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: apiIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
        apiIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PropertyController::apiIndex
 * @see app/Http/Controllers/PropertyController.php:123
 * @route '/api/properties'
 */
        apiIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: apiIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    apiIndex.form = apiIndexForm
const PropertyController = { landing, index, create, store, edit, update, destroy, destroyImage, show, apiIndex }

export default PropertyController