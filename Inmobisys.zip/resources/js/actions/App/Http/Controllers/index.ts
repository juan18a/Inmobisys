import PropertyController from './PropertyController'
import Admin from './Admin'
import ChatProxyController from './ChatProxyController'
import Settings from './Settings'
const Controllers = {
    PropertyController: Object.assign(PropertyController, PropertyController),
Admin: Object.assign(Admin, Admin),
ChatProxyController: Object.assign(ChatProxyController, ChatProxyController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers