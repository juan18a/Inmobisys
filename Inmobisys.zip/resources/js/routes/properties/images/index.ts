import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
export const destroy = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/properties/{property}/images/{image}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
destroy.url = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    property: args[0],
                    image: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        property: typeof args.property === 'object'
                ? args.property.slug
                : args.property,
                                image: typeof args.image === 'object'
                ? args.image.id
                : args.image,
                }

    return destroy.definition.url
            .replace('{property}', parsedArgs.property.toString())
            .replace('{image}', parsedArgs.image.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
destroy.delete = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
    const destroyForm = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PropertyController::destroy
 * @see app/Http/Controllers/PropertyController.php:277
 * @route '/properties/{property}/images/{image}'
 */
        destroyForm.delete = (args: { property: string | { slug: string }, image: number | { id: number } } | [property: string | { slug: string }, image: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const images = {
    destroy: Object.assign(destroy, destroy),
}

export default images