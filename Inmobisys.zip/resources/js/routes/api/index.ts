import properties from './properties'
const api = {
    properties: Object.assign(properties, properties),
}

export default api