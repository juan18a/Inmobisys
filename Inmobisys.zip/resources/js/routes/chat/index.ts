import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ChatProxyController::send
 * @see app/Http/Controllers/ChatProxyController.php:12
 * @route '/chat'
 */
export const send = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

send.definition = {
    methods: ["post"],
    url: '/chat',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChatProxyController::send
 * @see app/Http/Controllers/ChatProxyController.php:12
 * @route '/chat'
 */
send.url = (options?: RouteQueryOptions) => {
    return send.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChatProxyController::send
 * @see app/Http/Controllers/ChatProxyController.php:12
 * @route '/chat'
 */
send.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: send.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChatProxyController::send
 * @see app/Http/Controllers/ChatProxyController.php:12
 * @route '/chat'
 */
    const sendForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: send.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChatProxyController::send
 * @see app/Http/Controllers/ChatProxyController.php:12
 * @route '/chat'
 */
        sendForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: send.url(options),
            method: 'post',
        })
    
    send.form = sendForm
const chat = {
    send: Object.assign(send, send),
}

export default chat