<?php echo e($slot); ?>

<?php /**PATH E:\Proyectos Programacion\ProyectosLaravel\Inmobisys\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>