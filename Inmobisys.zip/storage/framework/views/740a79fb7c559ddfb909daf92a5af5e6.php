<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Proyectos Programacion\ProyectosLaravel\Inmobisys\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>